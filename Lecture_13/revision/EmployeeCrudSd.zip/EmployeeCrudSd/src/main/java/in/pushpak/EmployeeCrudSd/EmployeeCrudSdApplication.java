package in.pushpak.EmployeeCrudSd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeCrudSdApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeCrudSdApplication.class, args);
	}

}
